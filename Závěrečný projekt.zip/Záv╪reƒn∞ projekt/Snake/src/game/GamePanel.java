package game;

import snake.Apple;
import snake.Snake;

import javax.swing.*;
import java.awt.*;

public class GamePanel extends JPanel implements Runnable {
    /**
     * How many cells will fit in the width
     */
    public static final int COLUMN = 18;
    /**
     * How many cells will fit in the height
     */
    public static final int ROW = 18;
    /**
     * The size of one cell in pixels. It is also responsible for the size of snake and textures.
     */
    public static final int CELL_SIZE = 32;

    /**
     * Number of cells in the column multiplied by the size of one cell
     */
    public static final int SCREEN_WIDTH = COLUMN * CELL_SIZE;
    /**
     * Number of cells in a row multiplied by the size of one cell
     */
    public static final int SCREEN_HEIGHT = ROW * CELL_SIZE;
    public static final int UPDATE_TIMER = 5; // Refresh the game loop x times per second
    /**
     * Counts the number of apples eaten
     */
    public static int apple_count;
    private Thread thread;
    public static Game game;
    public static Snake snake;
    public static Apple apple;

    public GamePanel() {
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);

        this.addKeyListener(new KeyInput());
        this.setFocusable(true);

        game = Game.START;
        snake = new Snake();
        apple = new Apple();

    }

    public void startGame() {
        thread = new Thread(this);
        thread.start();
    }

    private void update() {
        if(game == Game.PLAY) {
            snake.update();
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        apple.draw(g);
        snake.draw(g);

        UI.drawGrid(g);

        if(game == Game.OVER) UI.drawGameOver(g);

        if(game == Game.PLAY) UI.drawScore(g);

        if(game == Game.START) UI.drawStart(g);
    }

    @Override
    public void run() {
        double interval = 1000000000.0/UPDATE_TIMER;
        double delta = 0;
        long lastTime = System.nanoTime();

        while (thread != null) {
            long currently = System.nanoTime();
            delta += (currently - lastTime) / interval;
            lastTime = currently;
            if(delta >= 1) {
                update();
                repaint();
                delta--;
            }
        }
    }

    /**
     * Sets new values when the snakes dies
     */
    public static void gameOver(){
        snake = new Snake();
        game = Game.OVER;
    }


}