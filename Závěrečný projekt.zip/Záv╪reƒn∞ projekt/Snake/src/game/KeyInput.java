package game;

import snake.Direction;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyInput implements KeyListener {

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W -> {
                if(GamePanel.snake.direction != Direction.DOWN) GamePanel.snake.direction = Direction.UP;
            }
            case KeyEvent.VK_D -> {
                if(GamePanel.snake.direction != Direction.LEFT) GamePanel.snake.direction = Direction.RIGHT;
            }
            case KeyEvent.VK_S -> {
                if(GamePanel.snake.direction != Direction.UP)  GamePanel.snake.direction = Direction.DOWN;
            }
            case KeyEvent.VK_A -> {
                if(GamePanel.snake.direction != Direction.RIGHT) GamePanel.snake.direction = Direction.LEFT;
            }
            case KeyEvent.VK_ENTER -> {
                if(GamePanel.game != Game.PLAY) GamePanel.game = Game.PLAY;
            }
        }
    }

    //region Unnecessary methods
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
    //endregion
}
