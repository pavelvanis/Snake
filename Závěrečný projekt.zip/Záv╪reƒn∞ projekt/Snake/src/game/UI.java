package game;

import java.awt.*;

public class UI {

    /**
     * Draws the grid
     */
    public static void drawGrid(Graphics g) {
        g.setColor(Color.gray);

        for(int row = 0; row < GamePanel.ROW; row++) {
            g.drawLine(0, row * GamePanel.CELL_SIZE, GamePanel.SCREEN_WIDTH, row * GamePanel.CELL_SIZE);
        }
        for (int col = 0; col < GamePanel.COLUMN; col++) {
            g.drawLine(col * GamePanel.CELL_SIZE, 0, col * GamePanel.CELL_SIZE, GamePanel.SCREEN_HEIGHT);
        }

        // Two additional lines edge right and bottom side
        g.drawLine(GamePanel.SCREEN_WIDTH - 1, 0, GamePanel.SCREEN_WIDTH - 1, GamePanel.SCREEN_HEIGHT);
        g.drawLine(0, GamePanel.SCREEN_HEIGHT - 1, GamePanel.SCREEN_WIDTH, GamePanel.SCREEN_HEIGHT - 1);
    }

    /**
     * Draws the game over menu
     */
    public static void drawGameOver(Graphics g) {
        g.setFont(g.getFont().deriveFont(Font.BOLD, (float)(GamePanel.COLUMN * GamePanel.CELL_SIZE/10)));
        g.setColor(Color.white);
        String text = "You've los";

        int textLength = (int)g.getFontMetrics().getStringBounds(text, g).getWidth();
        int textX = GamePanel.SCREEN_WIDTH/2 - textLength/2;
        int textY = GamePanel.SCREEN_HEIGHT/4;

        g.drawString(text, textX, textY);
    }
    /**
     * Draws the start menu
     */
    public static void drawStart(Graphics g){
        g.setFont(g.getFont().deriveFont(Font.BOLD, (float)(GamePanel.COLUMN * GamePanel.CELL_SIZE/10)));
        g.setColor(Color.white);
        String text = "Press ENTER"  ;

        int textLength = (int)g.getFontMetrics().getStringBounds(text, g).getWidth();
        int textX = GamePanel.SCREEN_WIDTH/2 - textLength/2;
        int textY = GamePanel.SCREEN_HEIGHT/2;

        g.drawString(text, textX, textY);
    }
    /**
     * Draws the score
     */
    public static void drawScore(Graphics g) {
        Font font = new Font("Helvetica", Font.BOLD, 46);
        String msg = "" + GamePanel.apple_count;
        g.setFont(font);
        g.setColor(Color.white);
        g.drawString(msg, GamePanel.COLUMN / 2 * GamePanel.CELL_SIZE, font.getSize());
    }

}
