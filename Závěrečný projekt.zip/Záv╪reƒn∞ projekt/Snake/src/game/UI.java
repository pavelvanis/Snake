package game;

import java.awt.*;

public class UI {
    public static void drawGrid(Graphics g) {
        g.setColor(Color.gray);

        for(int row = 0; row < GamePanel.ROW; row++) {
            g.drawLine(0, row * GamePanel.CELL_SIZE, GamePanel.SCREEN_WIDTH, row * GamePanel.CELL_SIZE);
        }
        for (int col = 0; col < GamePanel.COLUMN; col++) {
            g.drawLine(col * GamePanel.CELL_SIZE, 0, col * GamePanel.CELL_SIZE, GamePanel.SCREEN_HEIGHT);
        }

        // Two additional lines edge right and bottom side
        g.drawLine(GamePanel.SCREEN_WIDTH - 1, 0, GamePanel.SCREEN_WIDTH - 1, GamePanel.SCREEN_HEIGHT);
        g.drawLine(0, GamePanel.SCREEN_HEIGHT - 1, GamePanel.SCREEN_WIDTH, GamePanel.SCREEN_HEIGHT - 1);
    }

    public static void drawGameOver(Graphics g) {
        g.setFont(g.getFont().deriveFont(Font.BOLD, (float)(GamePanel.COLUMN * GamePanel.CELL_SIZE/10)));
        g.setColor(Color.white);
        String text = "You've lost";

        int textLength = (int)g.getFontMetrics().getStringBounds(text, g).getWidth();
        int textX = GamePanel.SCREEN_WIDTH/2 - textLength/2;
        int textY = GamePanel.SCREEN_HEIGHT/4;

        g.drawString(text, textX, textY);
    }
}
