package game;

public enum Game {
    PLAY,
    OVER,
    START
}
