package snake;

import game.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

public class Apple {
    public int x, y;
    public BufferedImage image;

    public Apple() {
        this.x = setRandomX();
        this.y = setRandomY();

        try {
            image = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/textures/apple.png")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int setRandomX() {
        return Math.abs((int) (Math.random() * GamePanel.COLUMN - 1));
    }

    public int setRandomY() {
        return Math.abs((int) (Math.random() * GamePanel.ROW - 1));
    }

    public void draw(Graphics g) {
        g.setColor(Color.red);
        g.drawImage(image, x * GamePanel.CELL_SIZE, y * GamePanel.CELL_SIZE, GamePanel.CELL_SIZE, GamePanel.CELL_SIZE, null);
    }
}
