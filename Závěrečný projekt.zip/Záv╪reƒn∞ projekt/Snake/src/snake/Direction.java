package snake;

public enum Direction {
    UP,
    RIGHT,
    DOWN,
    LEFT
}
