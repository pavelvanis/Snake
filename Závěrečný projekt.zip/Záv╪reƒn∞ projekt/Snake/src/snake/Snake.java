package snake;

import game.Game;
import game.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

public class Snake {
    /**
     * Size of the snake
     */
    public short size;
    public Direction direction;

    BufferedImage[] head;

    public int[] x;
    public int[] y;

    public Snake() {
        x = new int[GamePanel.COLUMN];
        y = new int[GamePanel.ROW];
        head = new BufferedImage[4];
        direction = Direction.UP;
        size = 1;

        try {
            head[0] = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/textures/snake/head_up.png")));
            head[1] = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/textures/snake/head_right.png")));
            head[2] = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/textures/snake/head_down.png")));
            head[3] = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/textures/snake/head_left.png")));
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Snake position
        x[0] = GamePanel.COLUMN / 2;
        y[0] = GamePanel.ROW / 2;
    }

    public void update() {
        // Update the position of the other cells so that they move to the head of the snake
        for(int s = size; s > 0; s--) {
            x[s] = x[s-1];
            y[s] = y[s-1];
        }

        if(direction == Direction.UP) {
            y[0]--;
        }
        if(direction == Direction.RIGHT) {
            x[0]++;
        }
        if(direction == Direction.DOWN) {
            y[0]++;
        }
        if(direction == Direction.LEFT) {
            x[0]--;
        }

        /*
            Does not let the snake go over the edge of the map.
            If its head goes out of bounds, it teleports
            to the opposite side. Need to subtract 1 from
            the column and row, because their count starts at 0 (like an array).
         */
        if(x[0] > GamePanel.COLUMN - 1) x[0] = 0;
        if(x[0] < 0) x[0] = GamePanel.COLUMN - 1;

        if(y[0] > GamePanel.ROW - 1) y[0] = 0;
        if(y[0] < 0) y[0] = GamePanel.ROW - 1;

        // If the head of the snake is on the same coordinates as the apple, it will be eaten.
        if((x[0] == GamePanel.apple.x) && (y[0] == GamePanel.apple.y)) {
            GamePanel.apple.x = GamePanel.apple.setRandomX();
            GamePanel.apple.y = GamePanel.apple.setRandomY();
            this.size++;
            GamePanel.apple_count++;
        }
        for(int s = 1; s < size; s++) {
            // If the snake's body is at the same coordinate
            // as the apple, it will be moved to a different position.
            if((x[s] == GamePanel.apple.x) && (y[s] == GamePanel.apple.y)) {
                GamePanel.apple.x = GamePanel.apple.setRandomX();
                GamePanel.apple.y = GamePanel.apple.setRandomY();
            }
            // If a player collides with a body the game is over
            if((x[0] == x[s]) && (y[0] == y[s])) {
                GamePanel.game = Game.OVER;
            }
        }
    }

    public void draw(Graphics g) {
        BufferedImage image = null;

        switch (direction) {
            case UP -> image = head[0];
            case RIGHT -> image = head[1];
            case DOWN -> image = head[2];
            case LEFT -> image = head[3];
        }
        g.drawImage(image, x[0] * GamePanel.CELL_SIZE, y[0] * GamePanel.CELL_SIZE, GamePanel.CELL_SIZE, GamePanel.CELL_SIZE, null);

        // Draws the body of the snake
        g.setColor(Color.decode("#99e550"));
        for(int s = 1; s < size; s++) {
            g.fillRect(x[s] * GamePanel.CELL_SIZE, y[s] * GamePanel.CELL_SIZE, GamePanel.CELL_SIZE, GamePanel.CELL_SIZE);
        }
    }
}